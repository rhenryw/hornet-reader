(function () {
	'use strict';

	function wrapWords(text, before, after, join) {
		const delimiter = join || '';
		return text.split('').map((word) => `${before}${word}${after}`).join(delimiter);
	}

	function wrapWordsInChildElement(node) {
		if (node.nodeName === '#text') {
			const characters = node.textContent.split('');

			for (let i = 0; i < characters.length; i += 1) {
				const char = characters[i];
				if (char.length > 0) {
					const span = node.ownerDocument.createElement('span');
					span.className = 'js-detect-wrap';
					span.innerText = char;
					node.parentNode.insertBefore(span, node);
				}
			}

			node.parentNode.removeChild(node);
		} else if (node.innerText) {
			node.innerHTML = wrapWords(node.innerText, '<span class="js-detect-wrap">', '</span>');
		}
	}

	function wrapWordsInElement(node) {
		if (!node.firstChild) {
			wrapWordsInChildElement(node);
			return;
		}

		const siblings = [];
		let pointer = node.firstChild;
		do {
			siblings.push(pointer);
			pointer = pointer.nextSibling;
		} while (pointer);

		for (let i = 0; i < siblings.length; i += 1) {
			wrapWordsInElement(siblings[i]);
		}
	}

	function getLines(element) {
		wrapWordsInElement(element);

		const spans = element.getElementsByClassName('js-detect-wrap');
		const lines = [];
		let currentLine = [];
		let lastOffset = 0;

		for (let i = 0; i < spans.length; i += 1) {
			const span = spans[i];
			const offset = span.offsetTop + span.getBoundingClientRect().height;

			if (offset === lastOffset) {
				currentLine.push(span);
			} else {
				if (currentLine.length > 0) {
					lines.push(currentLine);
				}

				currentLine = [span];
			}

			lastOffset = offset;
		}

		if (currentLine.length > 0) {
			lines.push(currentLine);
		}

		return lines;
	}

	const detector = {
		wrapWords,
		wrapWordsInElement,
		wrapWordsInChildElement,
		getLines
	};

	if (typeof define === 'function' && define.amd) {
		define(() => detector);
	} else if (typeof module !== 'undefined' && module.exports) {
		module.exports = detector;
	} else {
		window.lineWrapDetector = detector;
	}
})();
(function() {
'use strict';

if (window.__waspLineInitialized) {
	return;
}
window.__waspLineInitialized = true;

// Linear interpolate between v0 and v1 at percent t
function lerp(v0, v1, t)
{
	return v0 * (1 - t) + v1 * t
}

// Convert a hex triplet (#XXXXXX) to an array containing red, green, and blue
function hex_to_rgb(hex)
{
	return hex.replace('#', '').match(/.{1,2}/g).map(
		x => parseInt(x, 16)
	);
}

// Color all lines in the page
function applyGradient(colors, color_text, gradient_size)
{
	const paragraphs = document.getElementsByTagName('p');
	const base_color = hex_to_rgb(color_text);
	let coloridx = 0;
	let lineno = 0;

	for (let paragraph of paragraphs) {
		const lines = lineWrapDetector.getLines(paragraph);

		for (let line of lines) {
			// Alternate between left and right for every color
			const active_color = hex_to_rgb(colors[coloridx]);

			// Flip array around if on left to color correctly
			const is_left = (lineno % 2 === 0);
			if(is_left) {
				line = Array.from(line).reverse();
			}

			// Color lines using lerp of RGB values
			for (let loc in line) {
				const t = 1 - (loc / (line.length * gradient_size / 50));
				const red = lerp(base_color[0], active_color[0], t);
				const green = lerp(base_color[1], active_color[1], t);
				const blue = lerp(base_color[2], active_color[2], t);

				line[loc].style.color = "rgb(" + (red|0) + "," + (green|0) + "," + (blue|0) + ")";
			}

			// Increment color index after every left/right pair, and lineno
			// after every line
			if (!is_left) {
				coloridx = (coloridx + 1) % colors.length;
			}
			lineno += 1;
		}
	}
}

function applyFontWeight()
{
	const paragraphs = document.getElementsByTagName('p');
	let lineno = 0;
	for (let paragraph of paragraphs) {
		const lines = lineWrapDetector.getLines(paragraph);
		for (let line of lines) {
			const isEven = (lineno % 2 === 0);
			for (let loc in line) {
				line[loc].style.color = '';
				line[loc].style.fontWeight = isEven ? '600' : '400';
			}
			lineno += 1;
		}
	}
}

function showAutoDomainPrompt(host)
{
	const existing = document.getElementById('waspline-auto-prompt');
	if (existing) {
		return;
	}
	const wrapper = document.createElement('div');
	wrapper.id = 'waspline-auto-prompt';
	wrapper.style.position = 'fixed';
	wrapper.style.left = '12px';
	wrapper.style.bottom = '12px';
	wrapper.style.zIndex = '2147483647';
	wrapper.style.background = 'rgba(20,20,20,0.92)';
	wrapper.style.color = '#fff';
	wrapper.style.padding = '10px 12px';
	wrapper.style.borderRadius = '8px';
	wrapper.style.boxShadow = '0 6px 20px rgba(0,0,0,0.25)';
	wrapper.style.fontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Helvetica Neue', Arial, sans-serif";
	wrapper.style.fontSize = '13px';
	const text = document.createElement('span');
	text.textContent = 'Add this site to auto domain list?';
	text.style.marginRight = '10px';
	const yes = document.createElement('button');
	yes.textContent = 'Yes';
	yes.style.marginRight = '6px';
	yes.style.background = '#4caf50';
	yes.style.color = '#fff';
	yes.style.border = 'none';
	yes.style.padding = '6px 10px';
	yes.style.borderRadius = '6px';
	yes.style.cursor = 'pointer';
	const no = document.createElement('button');
	no.textContent = 'No';
	no.style.background = '#9e9e9e';
	no.style.color = '#fff';
	no.style.border = 'none';
	no.style.padding = '6px 10px';
	no.style.borderRadius = '6px';
	no.style.cursor = 'pointer';
	wrapper.appendChild(text);
	wrapper.appendChild(yes);
	wrapper.appendChild(no);
	document.documentElement.appendChild(wrapper);
	let dismissed = false;
	function removePrompt() {
		if (dismissed) return;
		dismissed = true;
		if (wrapper && wrapper.parentNode) {
			wrapper.parentNode.removeChild(wrapper);
		}
	}
	const t = setTimeout(removePrompt, 3000);
	yes.addEventListener('click', function() {
		clearTimeout(t);
		chrome.runtime.sendMessage({ command: 'add_auto_domain', host: host || window.location.hostname }, function() {});
		removePrompt();
	});
	no.addEventListener('click', function() {
		clearTimeout(t);
		removePrompt();
	});
}

// Listen for messages in background script
chrome.runtime.onMessage.addListener((message) => {
	if (message.command === "apply_gradient") {
		applyGradient(
			message.colors, message.color_text, message.gradient_size
		);
	} else if (message.command === "apply_weight") {
		applyFontWeight();
	} else if (message.command === 'prompt_add_domain') {
		showAutoDomainPrompt(message.host);
	} else if (message.command === "reset") {
		// TODO: Make function to remove line detection spans
		applyGradient(
			[message.color_text], message.color_text, 0
		);
	}
});


})();